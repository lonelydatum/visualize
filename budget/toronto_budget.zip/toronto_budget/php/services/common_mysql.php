<?php
	$connection = mysql_connect("your_host_name.com", "your_user_name", "your_password") or 	die(mysql_error());
	mysql_select_db("your_database_name") or die(mysql_error());
?>
